//
//  main.swift
//  Spreadsheet
//
//  Created by Chris Eidhof on 01.07.14.
//  Copyright (c) 2014 Unsigned Integer. All rights reserved.
//

import Cocoa

NSApplicationMain(Process.argc, Process.unsafeArgv)
